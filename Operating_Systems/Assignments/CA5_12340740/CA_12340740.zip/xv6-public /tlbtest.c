#include "types.h"
#include "user.h"
#include "fcntl.h"

#define PAGESIZE 4096

int
main(int argc, char *argv[])
{
    if (argc != 3) {
        printf(1, "Usage: tlbtest <page_count> <trials>\n");
        exit();
    }

    int numpages = atoi(argv[1]);
    int trials = atoi(argv[2]);

    if (numpages <= 0 || trials <= 0) {
        printf(1, "Page count and trials must be positive integers\n");
        exit();
    }

    int jump = PAGESIZE / sizeof(int);  // step to touch one int per page

    printf(1, "PageCount\tTrials\tTicks\tPageFaults\n");

    int faults_before = getpagefaults();
    int start = uptime();

    // Allocate memory
    int *arr = (int *)sbrk(numpages * PAGESIZE);
    if (arr == (void *)-1) {
        printf(1, "sbrk failed!\n");
        exit();
    }

    // Access the pages repeatedly to simulate TLB usage
    for (int t = 0; t < trials; t++) {
        for (int i = 0; i < numpages * jump; i += jump) {
            arr[i] = i;  // Touch the page
        }
    }

    int end = uptime();
    int faults_after = getpagefaults();

    printf(1, "%d\t%d\t%d\t%d\n", numpages, trials, end - start,
           faults_after - faults_before);

    exit();
}
