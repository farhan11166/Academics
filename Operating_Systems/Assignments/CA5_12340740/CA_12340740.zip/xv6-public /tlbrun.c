#include "types.h"
#include "user.h"

#define PAGESIZE 4096
#define MAXPAGES 1024

int
main()
{
    int jump = PAGESIZE / sizeof(int);   // Step to touch one int per page
    printf(1, "PageCount\tTrials\tTicks\tPageFaults\n");

    for (int numpages = 1; numpages <= MAXPAGES; numpages *= 2) {
        int trials = 1000;

        int faults_before = getpagefaults();   // syscall to get page faults
        int start = uptime();                  // syscall to get current ticks

        // Allocate memory
        int *arr = (int*) sbrk(numpages * PAGESIZE);
        if (arr == (void*) -1) {
            printf(1, "sbrk failed!\n");
            exit();
        }

        // Access the pages repeatedly to trigger page faults
        for (int t = 0; t < trials; t++) {
            for (int i = 0; i < numpages * jump; i += jump) {
                arr[i] = i;   // Touch the page to trigger page fault
            }
        }

        int end = uptime();
        int faults_after = getpagefaults();

        printf(1, "%d\t%d\t%d\t%d\n", numpages, trials, end - start,
               faults_after - faults_before);
    }

    exit();
}
