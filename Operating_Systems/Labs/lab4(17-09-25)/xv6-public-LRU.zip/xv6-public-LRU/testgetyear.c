#include "types.h"
#include "stat.h"
#include "user.h"
int main(void) {
printf(1, "Current year from kernel: %d\n", getyear());
exit();
}
