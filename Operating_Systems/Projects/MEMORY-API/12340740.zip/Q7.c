#include <stdio.h>
#include <stdlib.h>
int main(){
int *data=malloc(100*(sizeof(int)));


free(data[12]);
return 0;





}