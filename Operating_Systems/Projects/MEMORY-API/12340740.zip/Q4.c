#include <stdio.h>
#include <stdlib.h>
int main(){
int *pp=malloc(48);
pp[0]=220606;
printf("%d",pp[0]);
return 0;
}