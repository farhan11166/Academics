#include <stdio.h>

int main() {
    int *ptr = NULL;   
    printf("Pointer value: %p\n", ptr);
    printf(" Trying to dereferenc  pointer: %d\n", *ptr);  
    
    return 0;
}
